# infoRun

Este Projeto foi um serviço prestado para escola de curso de informática intensivo InfoRun, você pode acessar o site [clicando aqui](https://inforun.co/)
